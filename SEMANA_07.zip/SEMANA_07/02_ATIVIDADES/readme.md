Para esta semana sua tarefa é criar um jogo baseado num dos seguintes temas:

-Desde que tenhamos um ao outro, os problemas nunca acabarão

-Decepção

-Extinção

-Não vemos coisas como elas são, vemos como nós somos.

-O que fazemos agora?

-Ritual

-Ondas

-Transmissão

-O que casa significa para você?

-Reparo

-Achados e perdidos

-Dualidade

O jogo deve possuir ao menos:

- Uma tela inicial

- Uma fase jogável

- Uma justificativa/explicação relacionando o tema escolhido e o jogo desenvolvido.

Ao terminar, salve o código fonte de seu jogo na sua pasta do Github e publique-o no seu GitPages.
