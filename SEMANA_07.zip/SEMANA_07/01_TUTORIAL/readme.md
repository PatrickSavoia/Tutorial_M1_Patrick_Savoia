# Etapa 7 - Máquina de Estados

Essa etapa tem por objetivo introduzir os conceitos sobre máquinas de estados. É um assunto complexo e que demandará alguns vídeos. Para iniciar, começaremos com ENUM/Enumerator.

Base da máquina de estados: [https://www.youtube.com/watch?v=xaEd02zP7D8](https://www.youtube.com/watch?v=xaEd02zP7D8)
